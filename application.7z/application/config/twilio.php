<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
//You can get these values from https://www.twilio.com/console
$config['twilio_sid']   = 'ACCOUNT SID';
$config['twilio_token'] = 'AUTH TOKEN';